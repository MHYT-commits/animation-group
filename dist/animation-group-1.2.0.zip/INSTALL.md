# Install Animation Group 1.2.0

1. Extract this ZIP into your Godot project folder (the folder containing
   project.godot). Merge the addons folder if it already exists.
2. Confirm the resulting path is:
   res://addons/animation_group/plugin.cfg
3. In Godot, open Project > Project Settings > Plugins and enable Animation Group.
4. Select an AnimationTree with an AnimationNodeBlendTree, then open the
   AnimationTree bottom panel. The graph toolbar includes Group, Members,
   Ungroup, Rename, and Tidy.

Select nodes of any blend-tree type and click Group. Select one group's title
bar before creating a node to add the new node to that group automatically.
Use Members to add or remove existing nodes. Left-drag across group title bars
to select several groups, then drag a selected title bar to move them together.

Full instructions and the MIT license are inside addons/animation_group/.
This package contains the reusable addon, with no project-specific auto-grouping.
Validated with Godot 4.5.1; editor integration may vary between Godot versions.
